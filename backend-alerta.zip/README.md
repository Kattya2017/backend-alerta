Recuerden que deben ejecutar 
```
npm install
```

para reconstruir los modulos de node

Recuerden que deben crear un archivo .env

```
crear un archivo .env complentado los datos que hay en el .example.env
```